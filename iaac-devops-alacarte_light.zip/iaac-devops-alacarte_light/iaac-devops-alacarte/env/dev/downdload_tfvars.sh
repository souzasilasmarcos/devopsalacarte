#!/bin/bash

# Defina seus valores
URL="https://35xdmz8mb2-vpce-0aa64cf3a6cedc7b0.execute-api.us-east-1.amazonaws.com/dev/upload/{bucket}/sqs-devops-alacarte.dev.tfvars.json"
API_KEY="CqhZvyU5he7NPQ3Fe04dZ5MJyMQwQ3Yz2z6bNXPQ"


# Baixa conteúdo com curl e imprime JSON como saída
payload=$(curl --silent --fail --location --request GET \
  --url "$URL" \
  --header "Content-Type: application/json" \
  --header "x-api-key: $API_KEY")

# Retorna como JSON para o Terraform
jq -n --arg paylload_json "$payload" '{"paylload_json": $paylload_json}'


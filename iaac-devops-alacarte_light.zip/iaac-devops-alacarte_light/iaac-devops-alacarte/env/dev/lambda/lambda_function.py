import json
import urllib3
import boto3
import os

http = urllib3.PoolManager(timeout=30.0)
s3 = boto3.client("s3")

REQUIRED_ENV_VARS = [
    "WEBHOOK_URL",
    "WEBHOOK_TOKEN_SQS",
    "WEBHOOK_TOKEN_PAYLOAD",
    "TARGET_FILENAME"
]

def get_env_vars():
    missing = [var for var in REQUIRED_ENV_VARS if not os.environ.get(var)]
    if missing:
        raise EnvironmentError(f"Variáveis de ambiente ausentes: {', '.join(missing)}")
    return (
        os.environ["WEBHOOK_URL"],
        os.environ["WEBHOOK_TOKEN_SQS"],
        os.environ["WEBHOOK_TOKEN_PAYLOAD"],
        os.environ["TARGET_FILENAME"]
    )

def infer_environment(key):
    if "dev" in key:
        return "dev"
    elif "hml" in key:
        return "hml"
    else:
        print("Nenhum ambiente detectado no caminho. Usando 'hml' como fallback.")
        return "hml"

def clean_filename(key):
    return key[len("load/"):] if key.startswith("load/") else key.split("/")[-1]

def lambda_handler(event, context):
    try:
        base_url, token_sqs, token_payload, target_filename = get_env_vars()

        # Validar evento S3
        try:
            record = event['Records'][0]
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
        except (KeyError, IndexError) as e:
            raise ValueError(f"Evento S3 malformado: {str(e)}")

        env = infer_environment(key)
        filename = clean_filename(key)

        # Interpretar TARGET_FILENAME como lista
        target_list = [f.strip() for f in target_filename.split(",")]

        # Determinar qual token usar
        if filename in target_list:
            print("Arquivo SQS identificado:", filename)
            token = token_sqs
        elif filename.startswith("request-payload-") and filename.endswith(".json"):
            print("Arquivo Payload identificado:", filename)
            token = token_payload
        elif filename.endswith(".tfvars.json"):
            if filename == "sqs-account.dev.tfvars.json":
                print("Arquivo SQS identificado via TFVARS:", filename)
                token = token_sqs
            else:
                print("Arquivo TFVARS identificado:", filename)
                token = token_payload
        else:
            print(f"Arquivo ignorado: {filename}")
            return {
                "statusCode": 204,
                "body": f"Arquivo ignorado: {filename}"
            }

        # Baixar conteúdo do arquivo
        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            content = response['Body'].read().decode("utf-8")
            json_data = json.loads(content)
        except s3.exceptions.NoSuchKey:
            raise FileNotFoundError(f"Arquivo não encontrado no S3: {key}")
        except json.JSONDecodeError:
            raise ValueError(f"Conteúdo JSON inválido no arquivo: {key}")

        # Montar payload
        payload = {
            "env": env,
            "payloadFile": filename
        }

        webhook_url = f"{base_url}?token={token}"
        headers = {
            "Content-Type": "application/json"
        }

        print(f"Enviando para Webhook: {webhook_url}")
        print("Ambiente:", env)
        print("Token usado:", token)
        print("Payload:", json.dumps(payload))

        # Enviar para Webhook
        try:
            response = http.request(
                "POST",
                webhook_url,
                body=json.dumps(payload, ensure_ascii=False),
                headers=headers
            )
            print(f"Webhook enviado. Status HTTP: {response.status}")
            print("Resposta do webhook:", response.data.decode("utf-8"))
            return {
                "statusCode": response.status,
                "body": f"Webhook enviado com sucesso: {key}"
            }
        except Exception as e:
            raise ConnectionError(f"Falha ao enviar para Webhook: {str(e)}")

    except Exception as e:
        print(f"Erro: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Erro: {str(e)}"
        }

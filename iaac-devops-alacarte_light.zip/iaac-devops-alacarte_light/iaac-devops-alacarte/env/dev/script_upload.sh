#!/bin/bash

BUCKET="dev-api-upload-s3"
LOCAL_DIR="/home/silasmarcosdesouza/terraform/iaac-devops/iaac-devops-alacarte/env/dev/web/"

upload_file() {
  FILE=$1
  EXT="${FILE##*.}"
  MIME="application/octet-stream"

  case "$EXT" in
    html) MIME="text/html" ;;
    js) MIME="application/javascript" ;;
    css) MIME="text/css" ;;
    json) MIME="application/json" ;;
    png) MIME="image/png" ;;
    jpg|jpeg) MIME="image/jpeg" ;;
    svg) MIME="image/svg+xml" ;;
  esac

  aws s3 cp "$FILE" "s3://$BUCKET/${FILE#$LOCAL_DIR/}" \
    --content-type "$MIME" --profile DEV_NPRD-Infraestrutura_SSO-652613197255
}

export -f upload_file

find "$LOCAL_DIR" -type f | while read FILE; do
  upload_file "$FILE"
done

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_sns_topic.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cmk_id"></a> [cmk\_id](#input\_cmk\_id) | The ID of an AWS-managed customer master key (CMK) for Amazon SNS or a custom CMK | `string` | `"alias/aws/sns"` | no |
| <a name="input_cost_center"></a> [cost\_center](#input\_cost\_center) | n/a | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_max_delay_target"></a> [max\_delay\_target](#input\_max\_delay\_target) | the maximum delay for a retry | `number` | `20` | no |
| <a name="input_max_receives_per_second"></a> [max\_receives\_per\_second](#input\_max\_receives\_per\_second) | The maximum number of deliveries per second, per subscription. | `number` | `10` | no |
| <a name="input_min_delay_target"></a> [min\_delay\_target](#input\_min\_delay\_target) | the minimum delay for a retry | `number` | `20` | no |
| <a name="input_name"></a> [name](#input\_name) | the name of the topic. | `string` | n/a | yes |
| <a name="input_num_max_delay_retries"></a> [num\_max\_delay\_retries](#input\_num\_max\_delay\_retries) | the number of retries in the post-backoff phase, with the maximum delay between them. | `number` | `0` | no |
| <a name="input_num_min_delay_retries"></a> [num\_min\_delay\_retries](#input\_num\_min\_delay\_retries) | the number of retries in the pre-backoff phase, with the specified minimum delay between them. | `number` | `0` | no |
| <a name="input_num_no_delay_retries"></a> [num\_no\_delay\_retries](#input\_num\_no\_delay\_retries) | the number of retries to be done immediately, with no delay between them | `number` | `0` | no |
| <a name="input_num_retries"></a> [num\_retries](#input\_num\_retries) | the total number of retries, including immediate, pre-backoff, backoff, and post-backoff retries. | `number` | `3` | no |
| <a name="input_owner"></a> [owner](#input\_owner) | n/a | `string` | n/a | yes |
| <a name="input_workload"></a> [workload](#input\_workload) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_all"></a> [all](#output\_all) | All objects |
